# diaf-report-tool
Security Testing Reporting Tool

**TO DO: update for docker compose!**

Run like this:

    docker build -t diaf-report-tool .
    docker run -ti --name diaf-001 -p 5001:5001 diaf-report-tool

Then connect to

http://localhost:5001/webapp

NB: This is for testing. It does not create output reports yet!
