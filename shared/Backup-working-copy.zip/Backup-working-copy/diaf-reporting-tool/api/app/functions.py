'''

File:       functions.py
Purpose:    Non-API Functions

'''

# Import Python Libraries
from flask import jsonify
from cvss import CVSS3
from operator import itemgetter

# Import DIAF Libraries
import config


# ---- Colours ----

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

# ---- Functions ----

def choose_response(json,tag,status):

    if len(json) == 0:
        return jsonify({tag: ""}),status
    else:
        return jsonify({tag: json}),status



def enrich_from_cvss (_issue={}):
    '''
    Return enriched data from a CVSS vector
    Performs safety checks to stop crashes as the library doesn't.
    '''

    if 'cvssvector' not in _issue.keys():
        _issue['cvssvector'] = config.CVSS_INFO_VECTOR

    if _issue['cvssvector'] == "":
        # They didn't set a cvss vector
        _issue['cvssvector'] = config.CVSS_INFO_VECTOR

    try:
        _cvss_object = CVSS3(_issue['cvssvector'])
    except:
        _cvss_object = CVSS3(config.CVSS_INFO_VECTOR)

    _severity = _cvss_object.severities()[0]

    # Rewrite to match from config (None --> Info)
    if _severity == "None":
        _severity = config.SEVERITIES[len(config.SEVERITIES)-1]

    _score = float(_cvss_object.scores()[0])

    _issue['cvssscore'] = _score
    _issue['severity'] = _severity

    return (_issue)


def sort_issues_cvss():
    '''
    Sort issues database by CVSS score
    '''

    _sorted_issues = sorted(config.issues, key=itemgetter('cvssscore'), reverse=True)
    _counter = 1
    for _i in _sorted_issues:
        _i['id'] = _counter
        _counter += 1

    config.issues = _sorted_issues


def generate_statistics():
    '''
    Generate Statistics from the Issues in memory
    '''

    # Blank the stats records
    for _sev in config.SEVERITIES:
        config.stats[_sev] = 0

    # Count the issue severities
    if len(config.issues) > 0:
        for _issue in config.issues:
            config.stats[_issue['severity']] += 1



