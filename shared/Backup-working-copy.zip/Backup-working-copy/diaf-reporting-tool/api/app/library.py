'''

File:       library.py
Purpose:    Functions for Issues Library

'''


# Import Python Libraries
import json
from operator import itemgetter

# Import DIAF Libraries
import config
import functions

# ---- Non API Functions ----

def load_issues_library(_file = config.LIBRARY_JSON):
    ''' Load the library of issues from a JSON file.
    Stored into config.library, sorted by title
    Option parameter: filepath.json
    '''

    # Initialise with an empty database
    config.library = []

    _library_file = f"{config.USERDATA}/{_file}"

    try:

        _f = open(_library_file)
        _loaded_data = json.load(_f)
        _f.close()

        _sorted_data = sorted(_loaded_data, key=itemgetter('title'), reverse=False)
        _counter = 1
        for _entry in _sorted_data:

            # Normalise the internal ID value
            _entry['id'] = _counter
            _counter += 1

            _entry = functions.enrich_from_cvss(_entry)

        config.library = _sorted_data

        print(f"{functions.bcolors.OKGREEN}[OK] Loaded Issues Library with {str(len(config.library))} issues{functions.bcolors.ENDC}")

    except IOError:
        print(f"{functions.bcolors.WARNING}[WARN] I/O error loading Issues Library from {config.LIBRARY_JSON}{functions.bcolors.ENDC}")




# ---- API Functions ----

def api_library_fetch_all():
    ''' Return all the issues in the library as JSON '''

    if len(config.library) > 0:
        return (functions.choose_response(config.library, 'success',200))
    else:
        return (functions.choose_response(['no issues in library database'], 'error',404))


def api_library_fetch_by_id(_id):
    ''' Return single issue from the library as JSON '''

    if len(config.library) > 0:

        # range check
        if (_id > 0) and (_id <= len(config.library)):
            return (functions.choose_response(config.library[_id-1], 'success',200))

        else:
            return (functions.choose_response(['id out of range'], 'error',400))

    else:
        return (functions.choose_response(['no issues in library database'], 'error',404))


def api_library_copy_by_id(_id):
    '''
    Uses backend to copy an issue from library to reported issues
    '''

    if config.library:

        # range check
        if (_id > 0) and (_id <= len(config.library)):

            config.issues.append(config.library[_id-1])

            return (functions.choose_response('added issue', 'success',200))

        else:

            return (functions.choose_response(['id out of range'], 'error',404))

    else:
        return (functions.choose_response(['no issues in library database'], 'error',404))


def api_library_count_all():
    ''' Return count of issues in the library as JSON '''

    if len(config.library) > 0:
        return (functions.choose_response(str(len(config.library)), 'success',200))
    else:
        return (functions.choose_response(['no issues in library database'], 'error',404))

