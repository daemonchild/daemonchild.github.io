'''

File:       project.py
Purpose:    Project Data handling functions

'''

# Import Python Libraries

# Import DIAF Libraries
import config
import functions


'''

NOT WRITTEN YET - OLD CODE BELOW

'''

def api_project_fetch():

    if config.project:
        return make_response(jsonify({'success': project}), 200)
    else:
        return make_response(jsonify({'error': 'no project loaded'}), 400)


def api_project_add():

    global project

    required = projectfields
    newproject = {}

    if request.form:
        for val in required:
            if val in request.form:
                newproject[val] = request.form[val]
        project = newproject

    else:
        project = demoproject

    if project:
        return (chooseResponse(project, 'success'))

