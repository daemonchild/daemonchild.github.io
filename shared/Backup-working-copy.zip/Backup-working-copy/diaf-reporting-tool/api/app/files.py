'''

File:       files.py
Purpose:    File handling handling functions

'''

# Import Python Libraries
import json
import os
from flask import send_from_directory

# Import DIAF Libraries
import config
import functions


def api_file_save_json(_file_name = config.DEFSAVE_JSON):

    _save_data = {}

    _save_data['issues']  = config.issues
    _save_data['project'] = config.project

    try:
        with open(config.USERDATA + "/" + _file_name, 'w') as _f:
            json.dump(_save_data, _f)

    except IOError:
        print(f"{functions.bcolors.WARNING}I/O error saving {_file_name}{functions.bcolors.ENDC}")

    return (functions.choose_response('saved ' + str(len(config.issues)) + ' issues as json', 'success',200))


def api_file_load_json(_file_name = config.DEFSAVE_JSON):

    _load_data = {}

    try:
        with open(config.USERDATA + "/" + _file_name, 'r') as _f:
            _load_data = json.load(_f)

        config.issues = _load_data['issues']
        config.project = _load_data['project']

    except IOError:
        print(f"{functions.bcolors.WARNING}I/O error loading {_file_name}{functions.bcolors.ENDC}")

    return (functions.choose_response('loaded ' + str(len(config.issues)) + ' issues as json', 'success',200))


def api_file_export_json (_file_name = config.DEFSAVE_JSON):
    '''
    Send the saved data file to the client
    '''

    _full_path = f"{config.USERDATA}/{_file_name}"

    exists = os.path.isfile(_full_path)

    if exists:
            print("File Exists")
            return (send_from_directory(directory=config.USERDATA,filename=_file_name ,mimetype="application/json", as_attachment=True))
    else:
            print("File NOT FOUND")
            return (functions.choose_response("no such file","error",400))




# Not linked, not used currently below here...


def api_load_csv():

    global issues

    inputfile = 'saved.csv'

    columns = issuefields

    # Empty the database
    issues = []

    try:
        with open(inputfile, 'r') as csvfile:
            reader = csv.DictReader(csvfile)

            for newissue in reader:
                # fix up for float and int values in the data to allow sorting
                cvss = CVSS3(newissue['cvssvector'])

                severities = cvss.severities()
                scores = cvss.scores()

                newissue['severity'] = severities[0]

                # We prefer Info to None :)
                if severities[0] == "None":
                    newissue['severity'] = "Info"

                newissue['cvssscore'] = float(scores[0])

                issues.append (newissue)

            sort_issues_cvss()


    except IOError:
        print("I/O error")

    return make_response(jsonify({'success': 'Loaded ' + str(len(issues)) + ' issues'}), 200)


