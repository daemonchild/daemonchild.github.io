@app.route('/' + APIURL+ '/save/sureformat/', methods=['GET'])
def api_save_sureformat():

    return (chooseResponse('sureformat', 'success'))


