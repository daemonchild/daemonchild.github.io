#!flask/bin/python

'''

File:       diaf-main.py
Purpose:    Main Flask App

'''

# Import Python Libraries
from flask import Flask, jsonify, make_response

# Import DIAF Libraries
import config
import functions
import library
import issue
import files
import webapp

# ---- Flask App Code ----

app = Flask(__name__)

# -- Global App Functions --

@app.errorhandler(404)
def this_404(error):
    return make_response(jsonify({'error': 'object not found'}), 404)

@app.errorhandler(503)
def this_503(error):
    return make_response(jsonify({'error': 'database unavailable'}), 503)

@app.errorhandler(500)
def this_500(error):
    return make_response(jsonify({'error': 'server error'}), 500)


# ---- Add API Routes - Using Method as verb ----

# -- Issue API --
app.add_url_rule('/api/issue', view_func=issue.api_issue_fetch_all, methods=['GET'])
app.add_url_rule('/api/issue', view_func=issue.api_issue_add, methods=['PUT'])
app.add_url_rule('/api/issue', view_func=issue.api_issue_clear, methods=['DELETE'])

app.add_url_rule('/api/issue/<int:_id>', view_func=issue.api_issue_fetch_by_id, methods=['GET'])
app.add_url_rule('/api/issue/<int:_id>', view_func=issue.api_issue_update_by_id, methods=['POST'])
app.add_url_rule('/api/issue/<int:_id>', view_func=issue.api_issue_delete, methods=['DELETE'])

# -- File API --
app.add_url_rule('/api/file/json', view_func=files.api_file_load_json, methods=['GET'])
app.add_url_rule('/api/file/json', view_func=files.api_file_save_json, methods=['POST'])

# -- Library API --
app.add_url_rule('/api/library', view_func=library.api_library_fetch_all, methods=['GET'])
app.add_url_rule('/api/library/<int:_id>', view_func=library.api_library_fetch_by_id, methods=['GET'])
app.add_url_rule('/api/library/copy/<int:_id>', view_func=library.api_library_copy_by_id, methods=['GET'])

# -- Count API --
app.add_url_rule('/api/count/library', view_func=library.api_library_count_all, methods=['GET'])
app.add_url_rule('/api/count/issue', view_func=issue.api_issue_fetch_stats, methods=['GET'])

# -- Web App Display --

app.add_url_rule('/', view_func=webapp.root, methods=['GET'])
app.add_url_rule('/webapp/', view_func=webapp.webapp, methods=['GET'])

# -- Reporting and Output --
app.add_url_rule('/api/report/json', view_func=files.api_file_export_json, methods=['GET'])
app.add_url_rule('/api/report/arse', view_func=files.api_file_export_json, methods=['GET'])

#app.add_url_rule('/report/', view_func=report-markdown.report, methods=['GET'])



# ---- API Startup  ----

''' 
Main Application Loop 
- Print logo and version information
- Load issues library
- Start Flask App
'''

if __name__ == "__main__":

    print (f"{functions.bcolors.FAIL}{config.LOGO}{functions.bcolors.ENDC}")
    print (f"{functions.bcolors.OKCYAN}DIAF - Detailed Issue Authoring Foundry, version {config.VERSION}, by {config.AUTHOR}{functions.bcolors.ENDC}")

    library.load_issues_library ()
    app.run(debug=True, host="0.0.0.0", port=5001)
