'''

File:       issue.py
Purpose:    Functions for handling reported Issues

'''


# Import Python Libraries
from flask import request

# Import DIAF Libraries
import config
import functions


# ---- Non API Functions ----


# ---- API Functions ----


def api_issue_fetch_all():
    ''' Return all issues as JSON '''

    if config.issues:
        functions.sort_issues_cvss()
        return (functions.choose_response(config.issues, 'success',200))
    else:
        return (functions.choose_response(['no issues in database'], 'error',404))


def api_issue_fetch_by_id(_id):
    ''' Return single issue as JSON '''

    # search issues for ID :)
    if config.issues:
        # range check
        if (_id > 0) and (_id <= len(config.issues)):
            return (functions.choose_response(config.issues[_id-1], 'success',200))

        else:

            return (functions.choose_response(['id out of range'], 'error',400))

    else:
        return (functions.choose_response(['no issues in database'], 'error',404))


def api_issue_add():
    '''
    Add new issue to the database
    '''

    _new_issue = {}

    if 'application/json' in request.content_type:

        if request.json:

            for _val in config.ISSUEFIELDS:
                if _val in request.json:
                    _new_issue[_val] = request.json[_val]

        else:
            return (functions.choose_response(['invalid data'], 'error', 400))

    elif 'application/x-www-form-urlencoded' in request.content_type:

        if request.form:

            for _val in config.ISSUEFIELDS:
                if _val in request.form:
                    _new_issue[val] = request.form[_val]

    else:

        return (functions.choose_response(['invalid data'], 'error', 400))

    if 'title' in _new_issue.keys():

        # Should this have been an update?
        for _issue in config.issues:
            if _issue['title'] == _new_issue['title']:
                return (functions.choose_response('issue with title exists', 'error',400))

        # enrich data where possible
        # severity and cvss

        _new_issue = functions.enrich_from_cvss(_new_issue)

        # finally, add the issue to the database
        config.issues.append(_new_issue)
        functions.sort_issues_cvss()

        return (functions.choose_response('issue added', 'success',200))


    else:
        # didn't set a title - everything else is ok to be missing.
        return (functions.choose_response('provide a title', 'error',400))



def api_issue_update_by_id(_id):
    '''
    Update an issue in the database
    '''

    #_new_issue = {}

    # range check
    if (_id > 0) and (_id <= len(config.issues)):

        if 'application/json' in request.content_type:

            if request.json:

                for _val in config.ISSUEFIELDS:
                    if _val in request.json:
                        config.issues[_id-1][_val] = request.json[_val]

            else:
                (functions.choose_response('invalid data', 'error', 400))


        elif 'application/x-www-form-urlencoded' in request.content_type:

            if request.form:

                for _val in config.ISSUEFIELDS:
                    if _val in request.form:
                        config.issues[_id-1][_val] = request.form[_val]

            else:
                (functions.choose_response('invalid data', 'error', 400))
        else:

            return (functions.choose_response('invalid content type', 'error', 400))

        config.issues[_id - 1]= functions.enrich_from_cvss(config.issues[_id - 1])
        functions.sort_issues_cvss()

        return (functions.choose_response('updated', 'success', 200))

    else:
        return (functions.choose_response('if out of range', 'error', 400))


def api_issue_delete(_id):
    '''
    Remove an issue from the database
    '''

    # range check
    if (_id > 0) and (_id <= len(config.issues)):

        config.issues.pop(_id-1)

        return (functions.choose_response('removed', 'success',200))

    else:
        return (functions.choose_response('id out of range', 'error', 400))


def api_issue_clear():
    '''
    Clear all issues
    API must be called with {'confirm': 'any string'} in JSON
    '''

    if 'application/json' in request.content_type:

        if request.json:

            if 'confirm' in request.json.keys():

                config.issues = []
                return (functions.choose_response('cleared all issues', 'success', 200))

            return (functions.choose_response('send confirm in json body', 'error', 400))

        else:
            return (functions.choose_response('send confirm in json body', 'error', 400))

    else:

        return (functions.choose_response('invalid content type', 'error', 400))



def api_issue_fetch_stats():
    '''
    Generate and return stats
    '''

    functions.generate_statistics()
    return (functions.choose_response(config.stats, 'success', 200))

