
// Global Variables
// should load these from a config file really?! :)

const version = "Frontend v0.2, API v0.2"

const url_svr = "http://localhost:5001/"
const url_api = "api/"
const url_static = url_svr + "static/"
const url_apibase = url_svr + url_api

function showFooter () {

    $('#footertext').val = "<p>DIAF - Detailed Information Authoring Foundry | " + version + "</p>";

}

// Utility Functions

const randomstring= (length = 8) => {
    return Math.random().toString(16).substr(2, length);
};



function download_url(url)
{
    // Download file from a URL

    var link = document.createElement("a");
    link.href = url;
    link.click();

}



// API Data Functions

function api_load_json () {

    // Use API to make server load data from file

    $.ajax({
      url: url_apibase + 'file/json',
      dataType: "JSON",
      type: "GET",
      success: function(data) {

        alert (data.success);

      }
    });
    ui_refresh();
}



function api_get_all_issues () {

    // Get all issues from API

    $.ajax({
      url: url_apibase + "issue",
      type: 'GET',
      dataType: "JSON",
      success: function(data) {

        ui_display_issuelist (data.success);

      }
    })
}




function api_get_issue (id) {

    // Get single issue 'id' from API

    $.ajax({
      url: url_apibase + "issue/" + id,
      type: 'GET',
      dataType: "JSON",
      success: function(data) {
        ui_clear_editzone ();
        ui_issue_editzone (data.success);
      }
    })
}












function api_update_issue () {

    var issue = $('#editzone_').val();

    console.log(issue);
    // update all fields
    // function not needed?

}



function api_new_issue (data) {

    //start ajax request
    $.ajax({
      url: url_apibase + 'issue',
      dataType: "JSON",
      type: 'PUT',
      contentType:'application/json',
      data: JSON.stringify(data),
      success: function(data) {
        ui_refresh();
      }
    })

}


function api_update_issue_field (field) {

    var id = $('#editzone_id').val();
    var data = {};
    data[field] = $('#editzone_' + field).val();

    //start ajax request
    $.ajax({
      url: url_apibase + 'issue/' + id,
      dataType: "JSON",
      type: 'POST',
      contentType:'application/json',
      data: JSON.stringify(data),
      success: function(data) {
        console.log('Updated issue ' + id + ' ' + field)
      }
    })

}


function api_get_issue_stats () {
    //start ajax request
    $.ajax({
      url: url_apibase + 'count/issue',
      dataType: "JSON",
      success: function(data) {

        $("#critical").html( data.success.Critical );
        $("#high").html( data.success.High );
        $("#medium").html( data.success.Medium );
        $("#low").html( data.success.Low );
        $("#info").html( data.success.Info );

      }
    });
}

function api_library_copy (id) {

    // rewrite!! to get issue from library and add as new one
    // two ajax requests

    $.ajax({
      url: url_apibase + 'library/copy/' + id,
      dataType: "JSON",
      type: 'GET',
      success: function(data) {
        ui_refresh();
      }
    })

}

function api_del_issue (id) {

    if (confirm('Delete issue (cannot be undone)?') == true) {

        $.ajax({
            url: url_apibase + 'issue/' + id,
            dataType: "JSON",
            type: 'DELETE',
            success: function(data) {
                ui_refresh ();
            }
        })
    }
}



function api_del_all_issues () {

       data = {'confirm': 'remove all issues'};

       $.ajax({
          url: url_apibase + 'issue',
          dataType: "JSON",
          type: 'DELETE',
          contentType:'application/json',
          data: JSON.stringify(data),
          success: function(data) {
            ui_refresh();
          }
        });
}





function api_save_json () {

    $.ajax({
      url: url_apibase + 'file/json',
      type: "POST",
      dataType: "JSON",
      success: function(data) {

        alert (data.success);

      }
    });

}


function api_report_json (){

    $.ajax({
      url: url_apibase + 'report/json',
      dataType: "JSON",
      type: 'GET',
      success: function(data) {

        alert ("You should have a file!?");

      }
    })

}


// User Interface Functions

function ui_new_issue_empty () {

    var data = {};
    data.title = "New Issue " + randomstring();
    console.log (data);

    api_new_issue (data);

}

function ui_clear_editzone () {

    // Clear Edit Zone Fields

    $("[id^='editzone_']").val('');

}

function ui_issue_editzone (issue) {

    $.each(issue, function (key, value) {

        htmlid = '#editzone_' + key;
        $(htmlid).val(value);

    });

    var img_source = url_static + 'images/speedo_' + issue['severity'].toLowerCase() + '.png';
    $('#editzone_speedo').attr("src",img_source);

    var calc_link = "https://www.first.org/cvss/calculator/3.1#" + issue['cvssvector'];
    $('#editzone_calclink').attr("href",calc_link);


}


function ui_clear_issuelist () {

        $("#issueslist").find("tr:gt(0)").remove();

}


function ui_display_issuelist (issues) {

    var maxtitle = 29;

    ui_clear_issuelist ();

    for (let index of issues) {
        var issue = '';
        issue += '<tr>';
        issue += '<td>' +
        index.id + '</td>';

        if (index.title.length > maxtitle) {

            issue += '<td>' + index.title.substring(0,maxtitle-5) + '[...]</td>';

        } else {
            issue += '<td>' + index.title + '</td>';
        }

        issue += '<td>' +
        index.severity + '</td>';

        issue += '<td>' + '<button name="edit' + index.id + '" onclick=api_get_issue(' + index.id + ')><img src="/static/images/edit24.png" width="12px" height="12px"></button><button name="del' + index.id + '" onclick=api_del_issue(' + index.id + ')><img src="/static/images/delete24.png" width="12px" height="12px"></button> </td>';


        issue += '</tr>';

        $('#issueslist').append(issue);
    }
}

function ui_import_json () {

$('#select_file').trigger('click');


    var files = document.getElementById('select_file').files;
    console.log(files);
    if (files.length <= 0) {
        return false;
    }

if (confirm('Merge issues from file?') == true) {


  var fr = new FileReader();

  fr.onload = function(e) {
    var result = JSON.parse(e.target.result);
        for  (let index of result.issues) {
            api_new_issue (index);
        }
  }

  fr.readAsText(files.item(0));
  document.getElementById('select_file').files = "";

}

}

function ui_get_all_issues () {

    api_get_all_issues ();

}




function ui_report_json () {

    // Get the userdata as saved on the server

    url = url_apibase + "report/json";
    console.log(url);
    download_url(url);

}

function ui_del_all_issues () {

   if (confirm('Delete ALL issues (cannot be undone)?') == true) {

        api_del_all_issues ();

   }

}

function ui_refresh () {

    ui_clear_issuelist();
    ui_clear_editzone();
    api_get_issue_stats ();
    ui_get_all_issues();

}

// jquery initialise document stuff

$(document).ready(function(){

    ui_refresh();
    showFooter ();

    //issuedescription = new EasyMDE({element: $('#textareadescription')[0]});

});

