from flask import render_template
import config

def root():
    ''' Display information page '''

    return render_template('info.html')


def webapp():
    ''' Display webapp page '''

    return render_template('webapp.html', library=config.library)

