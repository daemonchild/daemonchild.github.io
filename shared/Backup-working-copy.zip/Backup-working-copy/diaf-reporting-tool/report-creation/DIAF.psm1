# DIAF  - Module File


# Check for Prerequisite Modules
function CheckRequirements {

    Begin {

        [System.Array]$Requirements = "ImportExcel", "PSCVSS"
        [Bool]$Status = $True

    } # Begin Block

    Process {
        foreach ($Req in $Requirements) {

            if (!(Get-Module -ListAvailable -Name $Req)) {
       
                Write-Host "[FAIL] Required Powershell Module $Req  not Installed" -ForegroundColor Red
                Write-Host "[INFO] Run: Install-Module -name $Req -scope CurrentUser" -ForegroundColor Yellow
                $Status = $False

            } 

        } 
    } # Process Block

    End {

        Return $Status

    } # End Block

} # End Function


write-host "[Importing] D. I. A. F. Reporting Module" -ForegroundColor White

if (CheckRequirements) {

    # Source all functions in all ps1 files located in the functions folder
    write-host "[Info] Public functions are:" -ForegroundColor Cyan
    Get-ChildItem -Path $PSScriptRoot\functions\internal\*.ps1, $PSScriptRoot\functions\*.ps1 -Exclude *.tests.ps1, *profile.ps1 |
    ForEach-Object {
        . $_.FullName
    }

} else {

    write-host "[Info] Fix any errors and re-Import this module." -ForegroundColor Cyan

}

write-host ""   











