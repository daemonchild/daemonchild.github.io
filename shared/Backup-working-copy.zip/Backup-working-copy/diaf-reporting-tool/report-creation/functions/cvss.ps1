Import-Module PSCVSS

# Functions being imported...
write-host "[Imported] ConvertTo_Severity" -ForegroundColor Yellow

function ConvertTo_Severity ([Single]$CVSSScore) {

    Begin {
        [System.String]$severity = "Unknown"
    }

    Process {

        Switch ($cvssscore)
        {
            { $_ -eq 0 }      {
                $severity = "Info"; Break;
            }
            { $_ -lt 4 }      {
                $severity = "Low"; Break;
            }
            { $_ -lt 7 }      {
                $severity = "Medium"; Break;
            }
            { $_ -lt 9 }      {
                $severity = "High"; Break;
            }
            { $_ -ge 9 }      {
                $severity = "Critical"; Break;
            }
        }
    }

    End {

        Return $severity

    }

}


function Enrich_CVSS ([System.Array]$Issues)
{

    [System.Array]$enricheddata = $issues
    [Int16]$index = 0

    foreach ($issue in $issues)
    {
        # Calculate CVSS Base Score

        if ($issue.cvssvector.count -gt 0) {

            $issue | Add-Member -MemberType NoteProperty -Name "cvssscore" -Value (Get-CVSSScore ($issue.cvssvector)).'Base Score'

        } else {

            $issue |  Add-Member -MemberType NoteProperty -Name "cvssscore" -Value 0

        }

        # Add Severity
        $severity = ConvertTo_Severity -CVSSScore $issue.cvssscore
        $issue | Add-Member -MemberType NoteProperty -Name severity -Value $severity
        $enricheddata[$index] = $issue
        $index += 1

    }

    return $enricheddata

}

function SortIssues_CVSSScore ([System.Array]$Issues) {

    return ($issues | Sort-Object -Property cvssscore -Descending)

}