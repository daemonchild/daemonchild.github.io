

# Functions being imported...
write-host "[Imported] DumpIssues_Markdown" -ForegroundColor Yellow

Function ReportIssues_Markdown ([System.Array]$Issues) {

    Write-Output "<link rel='stylesheet' type='text/css' media='all' href='assets/report_format.css' />"
    Write-Output ""

    Write-Output """

# [PRJ_NAME]
## Security Assessment Report

![Logo]([PRJ_CLIENT]-logo.png)

	Prepared For: 	[PRJ_CLIENT]
	Reference: 		[PRJ_NO]
	Author:			[AUTHOR]
	Report Date:	[PRJ_DATE]
	Version:		0.1

  * * *

<div style='page-break-after: always'></div>

# Document Control
## Distribution List

Recipient	| Organisation
:---:| :---:
Red Team File, InfoSec|EUI
SRG Team, InfoSec|	EUI
[CLIENT_REP] | [CLIENT]

## Revision History

Date |	Version | Status | 	Author | Comments
:--- | :---: | :---: | :--- | :---
[PRJ_DATE] | 0.1 | DRAFT	| [AUTHOR] 	| Initial Draft
00-00-2020 | 0.2 | DRAFT | [QA-er] | QA
00-00-2020 | 0.3 | DRAFT | [AUTHOR]  | QA
00-00-2020 | 1.0 | Release	| [RT_MGR] 	| Release

  * * *

 <div style='page-break-after: always'></div>

# Executive Summary
## Overview

The EUI Red Team was engaged to perform a web application test against the [PRJ_NAME] applications.

The goal of this engagement was to assess and analyse the security posture of this resource and report any potential vulnerabilities. The findings from the engagement are presented in this report.

In general, the overall security stance of the resources under assessment was found to be good, with most security controls functioning as expected. However, several security issues were discovered.

The highest severity issue reported was: **[HIGHEST]**.

## Summary of Findings

[WRITE-THIS-YOURSELF]

  * * *

 <div style='page-break-after: always'></div>

    """

    Write-Output "## Risk Analysis"
    Write-Output ""
    WriteSeveritySummary_MD -Issues $Issues
    WriteRootCausesSummary_MD -Issues $Issues
    Write-Output ""

    Write-Output "## Issue Summary Table"
    Write-Output ""
    WriteIssuesSummary_MD -Issues $Issues
    Write-Output ""

    Write-Output " * * * "
    Write-Output "<div style='page-break-after: always'></div>"
    Write-Output ""

    Write-Output "# Executive Summary"
    Write-Output ""

    WriteDetails -sorted_data $Issues

    Write-Output  """

    * * *

	End of Report - Produced using DIAF_Powershell v0.1

    """


}


Function DumpIssues_Markdown ([System.Array]$Issues) {

    Write-Output "<link rel="stylesheet" type="text/css" media="all" href="assets/report_format.css" />"
    WriteDetails -sorted_data $Issues

}


Function WriteMD_Table ([System.Array]$Table) {

    Begin {

        $line1 = ""
        $line2 = ""
        $line3 = ""
    }

    Process {
        for ($i=0; $i -le $table.count; $i++) {
            $line1 += ($table[$i].Name)
            if ($i -lt $table.count-1) {
                $line1 += "|"
            }
        }


        for ($i=0; $i -le $table.count-1; $i++) {
            $line2 += ":-:"
            if ($i -lt $table.count-1) {
                $line2 += "|"
            }
        }

        for ($i=0; $i -le $table.count-1; $i++) {
            $i_count = ($table | Where-Object {$_.Name -eq ($table[$i].Name)}).Count
            $line3 += $i_count
            if ($i -lt $table.count-1) {
                $line3 += "|"
            }
        }

    }

    End {
            Write-Output $line1
            Write-Output $line2
            Write-Output $line3
            Write-Output ""
            Write-Output ""
    }

}


function WriteRootCausesSummary_MD ([System.Array]$Issues) {

    [System.Array]$table = (CountIssues_Rootcause -Issues $Issues)

    $line1 = ""
    for ($i=0; $i -le $table.count; $i++) {
        $line1 += ($table[$i].Name)
        if ($i -lt $table.count-1) {
            $line1 += "|"
        }
    }

    $line2 = ""
    for ($i=0; $i -le $table.count-1; $i++) {
        $line2 += ":-:"
        if ($i -lt $table.count-1) {
            $line2 += "|"
        }
    }

    $line3 = ""
    for ($i=0; $i -le $table.count-1; $i++) {
        $i_count = ($table | Where-Object {$_.Name -eq ($table[$i].Name)}).Count
        $line3 += $i_count
        if ($i -lt $table.count-1) {
            $line3 += "|"
        }
    }

    Write-Output $line1
    Write-Output $line2
    Write-Output $line3
    Write-Output ""
    Write-Output ""

}


function WriteSeveritySummary_MD ([System.Array]$Issues) {

    [System.Array]$severity_table = (CountIssues_Severity -Issues $Issues)
    [System.Array]$total_issue_count = (CountIssues -Issues $Issues)

    $severities = "Critical", "High", "Medium", "Low", "Info"

    $line1 = ""
    foreach ($s in $severities) {
        $line1 += ($s+" |")

    }
    $line1 +=  "Total"


    $line2 = ""
    for ($s=0; $s -le $severities.count; $s++) {
        $line2 += ":-:"
        if ($s -lt $severities.count) {
            $line2 += "|"
        }
    }

    $line3 = ""
    foreach ($s in $severities) {

        $sev_count = ($severity_table | Where-Object {$_.Name -eq $s}).Count
        $line3 += ( "$sev_count |")
    }

    $line3 += ($total_issue_count)

    Write-Output $line1
    Write-Output $line2
    Write-Output $line3

    Write-Output ""
    Write-Output ""
}

function WriteIssuesSummary_MD ([System.Array]$Issues) {

    # Output Issues Summary Table
    $issue_count = 1
    Write-Output "Issue ID | Title |Risk | CVSS 3.0 |Root Cause "
    Write-Output ":-:|---|:-:|:-:|:-:"

    foreach ($issue in $issues)
    {
        $issue_id = ($issue_count.ToString()).PadLeft(3,"0")
        $output = $issue_id + "|" + $issue.title + "|" + $issue.severity + "|" + $issue.cvssscore + "|" + $issue.rootcause
        Write-Output $output

        $issue_count += 1
    }

    Write-Output "  * * * "

}

function WriteDetails ($sorted_data) {

    # Output Details
    $issue_count = 1
    foreach ($issue in $sorted_data) {

        $issue_id = ($issue_count.ToString()).PadLeft(3,"0")
        $output = "# $issue_id " + $issue.title
        Write-Output $output
        Write-Output ""

        $speedo = "![speedo](assets/images/speedo_" + ($issue.severity).ToLower() + ".png)"

        $output = "Risk: " + $issue.severity + " | CVSS Score | CVSS 3 Vector  "
        Write-Output $output
        Write-Output ":---: |:---:|:---"
        $output = $speedo + "| **" + $issue.cvssscore + "** |" + $issue.cvssvector
        Write-Output $output
        
        Write-Output ""
        Write-Output ""

        Write-Output "## Issue and Risk Description"
        Write-Output ""

        Write-Output $issue.description
        Write-Output ""
        Write-Output ""

        Write-Output "## Affected Assets"
        Write-Output ""

        Write-Output $issue.assets
        Write-Output ""
        Write-Output ""

        Write-Output "## Remediation"
        Write-Output ""

        Write-Output $issue.remediation
        Write-Output ""
        Write-Output ""

        Write-Output "## References"
        Write-Output ""
        # Make links (cycle through text, add a newline in between)

        Write-Output $issue.references
        Write-Output ""
        Write-Output ""

        Write-Output "CVE | CWE"
        Write-Output ":--- |:---"

        $output =  $issue.cve + "|" + $issue.cwe
        Write-Output $output
        Write-Output ""
        Write-Output ""

        Write-Output "Root Cause | Category"
        Write-Output ":--- |:---"

        $output =  $issue.rootcause + "|" + $issue.category
        Write-Output $output
        Write-Output ""
        Write-Output ""
        Write-Output "  * * * "
        Write-Output ""

        Write-Output "<div style=`"page-break-after: always`"></div>"
        Write-Output ""

        $issue_count += 1

    }

}
