Import-Module ImportExcel

# Functions being imported...
write-host "[Imported] Open_Issues (csv/xlsx/json)" -ForegroundColor Yellow

function Open_Issues ([String]$Path) {
    
    Begin {
        [System.Array]$loaded_data = @()
        [System.Array]$enriched_data = @()
        [System.Array]$sorted_data = @()
    }

    Process {

        $tokens = $path.split('.')
        if ($tokens[$tokens.count-1]-eq "xlsx") {
    
            $loaded_data = Import-Excel -path $path
    
        } elseif ($tokens[$tokens.count-1]-eq "csv") {

            $loaded_data = (Import-CSV -path $path)

        } elseif ($tokens[$tokens.count-1]-eq "json") {

            $loaded_data = (Get-Content -Path $path | ConvertFrom-Json).issues
    
        } else {
    
            write-host "[FAILED] Didn't recognise filetype" -ForegroundColor Red
    
        }

        # Enrich the Data
        $enriched_data = Enrich_CVSS -Issues $loaded_data
        $sorted_data = SortIssues_CVSSScore -Issues $enriched_data

    }

    End {

        return $sorted_data

    }

    
    
}

