Import-Module ImportExcel

# Functions being imported...
write-host "[Imported] DumpIssues_Excel" -ForegroundColor Yellow
write-host "[Imported] DumpIssues_CSV" -ForegroundColor Yellow
write-host "[Imported] DumpIssues_JSON" -ForegroundColor Yellow
write-host "[Imported] DumpIssues_XML" -ForegroundColor Yellow

function DumpIssues_Excel ([System.Array]$Issues,[String]$Path) {

     $Issues | Export-Excel -Path $Path

}


function DumpIssues_CSV ([System.Array]$Issues,[String]$Path) {

    $Issues | Export-CSV -Path $Path

}


function DumpIssues_JSON ([System.Array]$Issues,[String]$Path) {

    $Issues | ConvertTo-Json | Out-File -Path $Path

}


function DumpIssues_XML ([System.Array]$Issues,[String]$Path) {

    $Issues | Export-Clixml -Path $Path

}


Function DumpIssues_SureFormat ([System.Array]$Issues,[String]$Path) {

    Write-Host "Under Construction"
    return 0

}

