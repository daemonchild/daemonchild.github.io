
# Functions being imported...
write-host "[Imported] CountIssues" -ForegroundColor Yellow
write-host "[Imported] CountIssues_Severity" -ForegroundColor Yellow
write-host "[Imported] CountIssues_Rootcause" -ForegroundColor Yellow
write-host "[Imported] CountIssues_Category" -ForegroundColor Yellow

function CountIssues ([System.Array]$Issues) {

    return (($issues | Measure-Object).Count)

}
function CountIssues_Severity ([System.Array]$Issues) {

    return ($issues| ForEach-Object {$_.severity}| group-object | select-object Name,count)

}

function CountIssues_Rootcause ([System.Array]$Issues) {

    return ($issues | ForEach-Object {$_.rootcause}| group-object | select-object Name,count)

}

function CountIssues_Category ([System.Array]$Issues) {

    return ($issues | ForEach-Object {$_.category}| group-object | select-object Name,count)

}

